EXEC	 [dbo].[SP_DB_Tables_Add_Status_Location_ID_Columns]
go
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.tbl_TmpLedger
	DROP CONSTRAINT DF_tbl_TmpLedger_Status
GO
CREATE TABLE dbo.Tmp_tbl_TmpLedger
	(
	Location_ID numeric(18, 0) NOT NULL,
	ID numeric(18, 0) NOT NULL IDENTITY (1, 1),
	Dated smalldatetime NULL,
	sFor varchar(50) NULL,
	No nchar(20) NULL,
	Detail varchar(MAX) NULL,
	Debit numeric(18, 2) NULL,
	Credit numeric(18, 2) NULL,
	Amount numeric(18, 2) NULL,
	CostPrice numeric(18, 2) NULL,
	SalePrice numeric(18, 2) NULL,
	Total numeric(18, 2) NULL,
	Timing datetime NULL,
	Status varchar(50) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_tbl_TmpLedger SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.Tmp_tbl_TmpLedger ADD CONSTRAINT
	DF_tbl_TmpLedger_Status DEFAULT ('Unsubmitted') FOR Status
GO
SET IDENTITY_INSERT dbo.Tmp_tbl_TmpLedger ON
GO
IF EXISTS(SELECT * FROM dbo.tbl_TmpLedger)
	 EXEC('INSERT INTO dbo.Tmp_tbl_TmpLedger (Location_ID, ID, Dated, sFor, No, Detail, Debit, Credit, Amount, CostPrice, SalePrice, Total, Timing, Status)
		SELECT Location_ID, ID, Dated, sFor, No, Detail, Debit, Credit, Amount, CostPrice, SalePrice, Total, Timing, Status FROM dbo.tbl_TmpLedger WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_tbl_TmpLedger OFF
GO
DROP TABLE dbo.tbl_TmpLedger
GO
EXECUTE sp_rename N'dbo.Tmp_tbl_TmpLedger', N'tbl_TmpLedger', 'OBJECT' 
GO
ALTER TABLE dbo.tbl_TmpLedger ADD CONSTRAINT
	PK_tbl_TmpLedger PRIMARY KEY CLUSTERED 
	(
	Location_ID,
	ID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
COMMIT
go
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.tmp_Stock
	DROP CONSTRAINT DF_tmp_Stock_Status
GO
CREATE TABLE dbo.Tmp_tmp_Stock
	(
	Location_ID numeric(18, 0) NOT NULL,
	Item_ID numeric(18, 0) NULL,
	Store_ID numeric(18, 0) NULL,
	Qty numeric(18, 2) NULL,
	ID numeric(18, 0) NOT NULL IDENTITY (1, 1),
	Status varchar(50) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_tmp_Stock SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.Tmp_tmp_Stock ADD CONSTRAINT
	DF_tmp_Stock_Status DEFAULT ('Unsubmitted') FOR Status
GO
SET IDENTITY_INSERT dbo.Tmp_tmp_Stock ON
GO
IF EXISTS(SELECT * FROM dbo.tmp_Stock)
	 EXEC('INSERT INTO dbo.Tmp_tmp_Stock (Location_ID, Item_ID, Store_ID, Qty, ID, Status)
		SELECT Location_ID, Item_ID, Store_ID, Qty, ID, Status FROM dbo.tmp_Stock WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_tmp_Stock OFF
GO
DROP TABLE dbo.tmp_Stock
GO
EXECUTE sp_rename N'dbo.Tmp_tmp_Stock', N'tmp_Stock', 'OBJECT' 
GO
ALTER TABLE dbo.tmp_Stock ADD CONSTRAINT
	PK_tmp_Stock PRIMARY KEY CLUSTERED 
	(
	Location_ID,
	ID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
COMMIT
GO
----------------------------------------------------------------------------------------------
declare @Location_ID numeric(18,0)
set @Location_ID=(select top 1 Location_ID from tbl_Locations)
if not exists(select * from tbl_Accounts where Location_ID=@Location_ID and Account_ID=3102001)
insert into tbl_Accounts(Location_ID, Account_ID  ,Account_Name ,ClassId   ,Active ,StoreId   ,Reserved     ,
	[Type]     ,	TypeName     ,CreatedDate    ,	Opening   ,Balance ,Code    ,[Address]  ,City    ,NIC   ,	ContactNo   ,	Email    ,
	Website    ,Gender   ,	DepartmentId    ,DesignationId  ,	Remarks    ,TownId   ,Store   ,PurchaseDate ,Price   ,LastTransferDate  ,
	LastStore    ,PartNo    ,	PassportNo   ,ShoppingCardNo    ,	PlaceofIssue    ,Stock ,
	EmpCode,Created_Time,Comission)
values(@Location_ID,3102001  ,'Direct Sales' ,3102   ,'true'  ,1   ,'y'     ,'e','Employee',
	'2015-02-23 00:00:00.000'    ,0   ,0  ,3102001    ,'-'  ,'-'    ,'-'   ,'-'   ,'-'    ,'-'    ,
	'-'  ,-1    ,-1  ,'-'    ,1   ,'-'   ,'2015-02-23 00:00:00.000' ,0   ,'2015-02-23 00:00:00.000'  ,'-'    ,
	'-'     ,'-'    ,'-'     ,	'-'     ,0 ,	null,'2015-02-23 11:07:45.000',0)
GO
declare @Location_ID numeric(18,0)
set @Location_ID=(select top 1 Location_ID from tbl_Locations)
if not exists(select * from tbl_Accounts where Location_ID=@Location_ID and Account_ID=3104001)
insert into tbl_Accounts(Location_ID, Account_ID  ,Account_Name ,ClassId   ,Active ,StoreId   ,Reserved     ,
	[Type]     ,	TypeName     ,CreatedDate    ,	Opening   ,Balance ,Code    ,[Address]  ,City    ,NIC   ,	ContactNo   ,	Email    ,
	Website    ,Gender   ,	DepartmentId    ,DesignationId  ,	Remarks    ,TownId   ,Store   ,PurchaseDate ,Price   ,LastTransferDate  ,
	LastStore    ,PartNo    ,	PassportNo   ,ShoppingCardNo    ,	PlaceofIssue    ,Stock ,
	EmpCode,Created_Time,Comission)
values(@Location_ID,3104001  ,'Direct Order' ,3104   ,'true'  ,1   ,'y'     ,'o','OrderBroker',
	'2015-02-23 00:00:00.000'    ,0   ,0  ,3104001    ,'-'  ,'-'    ,'-'   ,'-'   ,'-'    ,'-'    ,
	'-'  ,-1    ,-1  ,'-'    ,1   ,'-'   ,'2015-02-23 00:00:00.000' ,0   ,'2015-02-23 00:00:00.000'  ,'-'    ,
	'-'     ,'-'    ,'-'     ,	'-'     ,0 ,	null,'2015-02-23 11:07:45.000',0)
	go
	declare @Location_ID numeric(18,0)
set @Location_ID=(select top 1 Location_ID from tbl_Locations)
if not exists(select * from tbl_Accounts where Location_ID=@Location_ID and Account_ID=1201000)
	insert into tbl_Accounts(Location_ID, Account_ID,
	Account_Name ,
	ClassId   ,
	Active ,
	StoreId   ,
	Reserved     ,
	[Type]     ,
	TypeName     ,
	CreatedDate    ,
	Opening   ,
	Balance ,
	Code    ,
	[Address]  ,
	City    ,
	NIC   ,
	ContactNo   ,
	Email    ,
	Website    ,
	Gender   ,
	DepartmentId    ,
	DesignationId  ,
	Remarks    ,
	TownId   ,
	Store   ,
	PurchaseDate ,
	Price   ,
	LastTransferDate  ,
	LastStore    ,
	PartNo    ,
	PassportNo   ,
	ShoppingCardNo    ,
	PlaceofIssue    ,
	Stock ,
	EmpCode) values(@Location_ID, 1201000,'Cash Customer','1201','True',	1,	'y','r','Customer',
	GETDATE(),	'0.00',	'0.00',	'1201000'	,'-',	'-','-'	,'-',	'-',
		'-'	,'-'	,'0'	,'0'	,'-',	1,'-',	GETDATE()
	,'0.00',GETDATE(),'-','-','-','-'	,'-',	'0.00','')
	go
	declare @Location_ID numeric(18,0)
set @Location_ID=(select top 1 Location_ID from tbl_Locations)
if not exists(select * from tbl_Accounts where Location_ID=@Location_ID and Account_ID=510100)
	INSERT [dbo].[tbl_Accounts] (Location_ID, [Account_ID], [Account_Name], 
[ClassId], [Active], [StoreId], [Reserved], [Type], [TypeName], [CreatedDate], 
[Opening], [Balance], [Code], [Address], [City], [NIC], [ContactNo], [Email], [Website], 
[Gender], [DepartmentId], [DesignationId], [Remarks], [TownId], [Store], [PurchaseDate],
 [Price], [LastTransferDate], [LastStore], [PartNo], [PassportNo], [ShoppingCardNo ], [PlaceofIssue ], [Stock],
  [EmpCode]) VALUES (@Location_ID,510100 , N'HMR', 5101, 1,1, 'y', 'y', N'ExpenseSubHead', 
  CAST(0x0000901A00000000 AS DateTime), 0,0.00 , '510100', '-', '-', '-', '-', '-', '-', '-', 0, 0, '-', 1 , '-',GETDATE(), 
  0, GETDATE(),
 '-', '-', '-', '-', '-', 0, NULL)
 go
 declare @Location_ID numeric(18,0)
set @Location_ID=(select top 1 Location_ID from tbl_Locations)
if not exists(select * from tbl_Stores where Store_ID=1  and Location_ID=@Location_ID)
 insert into tbl_Stores values(@Location_ID,1,'Shop','-','True')
 go
 declare @Location_ID numeric(18,0)
set @Location_ID=(select top 1 Location_ID from tbl_Locations)
if not exists(select * from tbl_AccClass where AccClass_ID=3104 and Location_ID=@Location_ID)
 insert into tbl_AccClass(Location_ID, AccClass_ID,AccClass_Name,CategoryId,Active,StoreId,Reserved)
 values(@Location_ID,3104,'Order Broker',31,'1',1,'y')
go
declare @Location_ID numeric(18,0)
set @Location_ID=(select top 1 Location_ID from tbl_Locations)
if not exists(select * from tbl_AccCategory where Location_ID=@Location_ID and AccCategory_ID=52)
insert into tbl_AccCategory(Location_ID, AccCategory_ID,AccCategory_Name,GroupId,Active,StoreId,Reserved)
 values(@Location_ID,52,'General Expense',5,'1',1,'y')
go
declare @Location_ID numeric(18,0)
set @Location_ID=(select top 1 Location_ID from tbl_Locations)
if not exists(select * from tbl_AccCategory where Location_ID=@Location_ID and AccCategory_ID=5201 )
insert into tbl_AccClass(Location_ID, AccClass_ID,AccClass_Name,CategoryId,Active,StoreId,Reserved)
 values(@Location_ID,5201,'General Expense',52,'1',1,'y')
go
 declare @Location_ID numeric(18,0)
set @Location_ID=(select top 1 Location_ID from tbl_Locations)
if not exists(select * from tbl_Transporter where Transporter_ID=1  and Location_ID=@Location_ID)
 insert into tbl_Transporter values(@Location_ID,1,'-','-','True')
 go
alter table tbl_TmpLedger
add Debit_Credit char(1)
go
alter table tbl_TmpLedger
add OrderBy varchar(50)
go
alter table tbl_TmpLedger
add Size1 numeric(18,4)
go
alter table tbl_TmpLedger
add Size2 numeric(18,4)
go
alter table tbl_TmpLedger add Item_ID numeric(18,0)
go

GO
 alter table tbl_TmpLedger
 add Account_Id numeric(18,0)

go
 alter table tbl_TmpLedger
 add Account_Name varchar(50)
 go
alter table tbl_TmpLedger
alter column Detail varchar(max)
GO
alter table tbl_TmpLedger alter column Detail nvarchar(max)
go
alter table tbl_TmpLedger
add SchQty numeric(18,3)
go
alter table tbl_TmpLedger
add TotalSch numeric(18,3)
go
alter table tbl_TmpLedger
add OutScheme numeric(18,3)
go
drop procedure  SP_Poster_tbl_AccCategory_Select
go
drop procedure  SP_Poster_tbl_AccClass_Select
go
drop procedure  SP_Poster_tbl_AccGroup_Select
go
drop procedure  SP_Poster_tbl_Accounts_Select
go
drop procedure  SP_Poster_tbl_ApplicationParameter_Select
go
drop procedure  SP_Poster_tbl_AuditStock_Select
go
drop procedure  SP_Poster_tbl_AuditStockDetail_Select
go
drop procedure  SP_Poster_tbl_BackUp_Select
go
drop procedure  SP_Poster_tbl_BalanceSheet_Select
go
drop procedure  SP_Poster_tbl_BankAdjustment_Select
go
drop procedure  SP_Poster_tbl_CashAdjustment_Select
go
drop procedure  SP_Poster_tbl_DailyClosingStock_Select
go
drop procedure  SP_Poster_tbl_DeletePurchase_Detail_Select
go
drop procedure  SP_Poster_tbl_DeletePurchases_Select
go
drop procedure  SP_Poster_tbl_DeleteSales_Detail_Select
go
drop procedure  SP_Poster_tbl_DeleteSales_Select
go
drop procedure  SP_Poster_tbl_DeleteTmpSales_Detail_Select
go
drop procedure  SP_Poster_tbl_DeleteTmpSales_Select
go
drop procedure  SP_Poster_tbl_Dep_Designation_City_Color_Size_Select
go
drop procedure  SP_Poster_tbl_EmpAttendance_Select
go
drop procedure  SP_Poster_tbl_EmplyeePayRoll_Select
go
drop procedure  SP_Poster_tbl_ExpenseEntry_Select
go
drop procedure  SP_Poster_tbl_Inv_Voucher_Detail_Select
go
drop procedure  SP_Poster_tbl_Inv_Voucher_Select
go
drop procedure  SP_Poster_tbl_IssueStock_Select
go
drop procedure  SP_Poster_tbl_IssueStockDetail_Select
go
drop procedure  SP_Poster_tbl_Item_Stock_PriceHistory_Select
go
drop procedure  SP_Poster_tbl_ItemBarcodePrint_Select
go
drop procedure  SP_Poster_tbl_ItemCategory_Select
go
DROP PROCEDURE SP_Poster_DayOC_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_AccCategory_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_AccClass_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_AccGroup_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Accounts_Insert;
go
DROP PROCEDURE SP_Poster_tbl_Accounts_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_ApplicationParameter_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_AuditStock_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_AuditStockDetail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_BackUp_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_BalanceSheet_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_BankAdjustment_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_CashAdjustment_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_DailyClosingStock_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_DeletePurchase_Detail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_DeletePurchases_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_DeleteSales_Detail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_DeleteSales_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_DeleteTmpSales_Detail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_DeleteTmpSales_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Dep_Designation_City_Color_Size_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_EmpAttendance_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_EmplyeePayRoll_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_ExpenseEntry_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Inv_Voucher_Detail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Inv_Voucher_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_IssueStock_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_IssueStockDetail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Item_Stock_PriceHistory_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_ItemBarcodePrint_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_ItemCategory_Insert;
go
DROP PROCEDURE SP_Poster_tbl_ItemCategory_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_ItemClass_Insert;
go
DROP PROCEDURE SP_Poster_tbl_ItemClass_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_ItemCompany_Insert;
go
DROP PROCEDURE SP_Poster_tbl_ItemCompany_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_ItemCountry_Insert;
go
DROP PROCEDURE SP_Poster_tbl_ItemCountry_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_ItemMultiBarcode_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Items_Insert;
go
DROP PROCEDURE SP_Poster_tbl_Items_Main_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Items_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_ItemSubClass_Insert;
go
DROP PROCEDURE SP_Poster_tbl_ItemSubClass_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_ItemUnit_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Locations_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Menu_Child_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Menu_Parent_Update_Status;;
go
DROP PROCEDURE SP_Poster_tbl_Nationality_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Payment_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_PaymentWiseCommission_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Purchase_Detail_Tmp_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Purchase_Detail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_PurchaseReturn_Detail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_PurchaseReturn_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Purchases_Tmp_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Purchases_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Quotations_Detail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Quotations_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Sales_Detail_Tmp_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Sales_Detail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Sales_Tmp_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_SalesReturn_Detail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_SalesReturn_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Stores_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_StoreStock_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_SupplierBalAdj_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_TmpBalanceSheet_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_TmpLedger_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_TmpStockActivity_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_User_Group_Access_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_User_Group_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_UserActivity_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Users_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Voucher_Detail_Update_Status;
go
DROP PROCEDURE SP_Poster_tbl_Voucher_Update_Status;
go
DROP PROCEDURE SP_Poster_tmp_Item_Stock_PriceHistory_Update_Status;
go
DROP PROCEDURE SP_Poster_tmp_Stock_Update_Status;
go
DROP PROCEDURE SP_Poster_tmp_StoreStock_Update_Status;
go
drop table InvItems
go
drop procedure SP_Poster_InvItems_Select
go
drop procedure SP_Poster_InvItems_Update_Status
--------------------------------------------------------------
go
drop procedure SP_Poster_tbl_CustomerBalAdj_Select
go
drop procedure SP_Poster_tbl_CustomerBalAdj_Update_Status
go
drop procedure SP_Poster_tbl_CustomerDailySheet_Select
go
drop procedure SP_Poster_tbl_CustomerDailySheet_Update_Status
go
drop procedure SP_Poster_tbl_DailyCash_Select
go
drop procedure SP_Poster_tbl_DailyCash_Update_Status
go
drop procedure SP_Poster_tbl_Instalments_Select
go
drop procedure SP_Poster_tbl_Instalments_Update_Status
go
drop procedure SP_Poster_tbl_Production_Consume_Select
go
drop procedure SP_Poster_tbl_Production_Consume_Update_Status
go
drop procedure SP_Poster_tbl_Production_Detail_Select
go
drop procedure SP_Poster_tbl_Production_Detail_Update_Status
go
drop procedure [dbo].[SP_Poster_tbl_Production_Select]
go
drop procedure SP_Poster_tbl_Production_Update_Status
go
drop procedure SP_Poster_tbl_ProductionIssueStock_Select
go
drop procedure SP_Poster_tbl_ProductionIssueStock_Update_Status

go
drop procedure SP_Poster_tbl_ProductionIssueStockDetail_Select
go
drop procedure SP_Poster_tbl_ProductionIssueStockDetail_Update_Status
go
drop procedure SP_Poster_tbl_ProductionMember_Select
go
drop procedure SP_Poster_tbl_ProductionMember_Update_Status
go
drop procedure SP_Poster_tbl_ProductionMemberStock_Select
go
drop procedure SP_Poster_tbl_ProductionMemberStock_Update_Status
go
drop procedure SP_Poster_tbl_ProductionReceiving_Consume_Select


go
drop procedure SP_Poster_tbl_ProductionReceiving_Consume_Update_Status
go
drop procedure SP_Poster_tbl_ProductionReceiving_Detail_Select
go
drop procedure SP_Poster_tbl_ProductionReceiving_Detail_Update_Status
go
drop procedure SP_Poster_tbl_ProductionReceiving_Select
go
drop procedure SP_Poster_tbl_ProductionReceiving_Update_Status

go
drop procedure SP_Poster_tbl_Purchase_Detail_Select
go
drop procedure SP_Poster_tbl_Purchase_Detail_Tmp_Select
go
drop procedure SP_Poster_tbl_Recipe_Select
go
drop procedure SP_Poster_tbl_Recipe_Update_Status
go
drop procedure SP_Poster_tbl_RecipeDetail_Select
go
drop procedure SP_Poster_tbl_RecipeDetail_Update_Status
go
drop procedure SP_Poster_tbl_RequestMaterial_Detail_Select
go
drop procedure SP_Poster_tbl_RequestMaterial_Detail_Update_Status
go
drop procedure SP_Poster_tbl_RequestMaterial_Select
go
drop procedure SP_Poster_tbl_RequestMaterial_Update_Status

go
drop procedure SP_Poster_tbl_Quotations_Detail_Select
go
drop procedure SP_Poster_tbl_Quotations_Select
go
drop procedure SP_Poster_tbl_Owner_Select
go
drop procedure SP_Poster_tbl_Owner_Update_Status
go
drop procedure SP_Poster_tbl_SupplierBalAdj_Select
go
drop procedure SP_Poster_tbl_TmpBalanceSheet_Select
go
drop procedure SP_Poster_tbl_SmsTemplates_Update_Status


go
drop procedure SP_Poster_tbl_SetItemPriceHistory_Select
go
drop procedure SP_Poster_tbl_SetItemPriceHistory_Update_Status
go
drop procedure SP_Poster_tbl_ShopIssueStock_Select
go
drop procedure SP_Poster_tbl_ShopIssueStock_Update_Status
go
drop procedure SP_Poster_tbl_ShopIssueStockDetail_Select
go
drop procedure SP_Poster_tbl_ShopIssueStockDetail_Update_Status
go
drop procedure SP_Poster_tbl_ShopSales_Detail_Select